# Team ZZHQC
この演習ではCT画像から新型肺炎の検出を構築することを目的としている。

# パワーポイント
https://1drv.ms/p/s!AuWO41J0evJnjm7uUBWQyDHhg84P?e=ZbubOV

# 背景
人工知能やコンピューターサイエンスの発展に伴い、医療問題の解決に人工知能を活用する例が増えてきており。

# データ
収集したデータセットには、10人合計2581枚の正常画像と、10人合計939枚の非正常画像が含まれています。    
学習セットには、8人合計2024枚の正常画像と、8人合計801枚の非正常画像が含まれています。      
テストセットには、2人合計557枚の正常画像と、2人合計138枚の非正常の画像が含まれています。

# 方法
5分割交差検証

# 結果
<img width="326" alt="image" src="https://user-images.githubusercontent.com/102012011/215363984-231faaa9-de4c-4a1c-ba04-40ee332fa934.png">          
<img width="429" alt="image" src="https://user-images.githubusercontent.com/102012011/215364398-8b4e61b4-df2b-4f14-85a9-d7c566e6269b.png">       
<img width="434" alt="image" src="https://user-images.githubusercontent.com/102012011/215364407-febf831a-b688-4c64-ae2a-e59dec6648cb.png">

# メンバーの役割
アルゴリズム担当：ZHANG ZIAHAO/ZHOU LIYOU/QIN CHANG   
プログラミング担当：ZHANG ZIHAO/ZHOU LIYOU/HU BOTAO      
テスト担当：QIN CHANG/HU BOTAO/CHEN XUANZHE   
スライド担当：ZHOU LIYOU    
発表担当：CHEN XUANZHE
